//
//  airbnb_clone_bApp.swift
//  airbnb−clone−b
//
//  Created by Alumno on 3/11/23.
//

import SwiftUI

@main
struct airbnb_clone_bApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
